int func0(void);
char *_strchr(char *, char);
