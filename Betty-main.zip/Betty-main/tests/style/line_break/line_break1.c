int func0(void)
{
	return (1); 
}
