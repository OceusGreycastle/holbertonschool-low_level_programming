int func0(char very_very_very_very_very_long_variable_name_just_to_test_length)
{
																																																																					return (1);
}
