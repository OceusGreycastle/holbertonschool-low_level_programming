static const char *test(
	test_chain_t (*chain)(int),
	test_t **cmd,
	token_t *token,
	const char *start)
{
	return (start);
}
